import { Component, EventEmitter, Input,Output,OnInit } from '@angular/core';

@Component({
  selector: 'app-employeecount',
  templateUrl: './employeecount.component.html',
  styleUrls: ['./employeecount.component.css']
})
export class EmployeecountComponent {
  @Input()
  all: number;
  @Input()
    male: number;
    @Input()
    female: number;

    // Holds the selected value of the radio button
    selectedRadioButtonValue: string = 'All';

  constructor() { }

  ngOnInit(): void {
  }

  @Output()
    countRadioButtonSelectionChanged: EventEmitter<string> =
                                        new EventEmitter<string>();
  onRadioButtonSelectionChange() {
    this.countRadioButtonSelectionChanged
            .emit(this.selectedRadioButtonValue);
  }
}
